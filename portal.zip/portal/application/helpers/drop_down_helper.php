<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	function getDropDownList($table, $columns) {
		$CI =& get_instance();
		$query = $CI->db->select($columns)->from($table)->get();
		
		if ($query->num_rows() >= 1) {
			$options1 = ['' => '-- Pilih '.ucwords($table).' --'];
			$options2 = array_column($query->result_array(), $columns[1], $columns[0]);
			$options = $options1 + $options2;
			return $options;
		}
		
		return $options = ['' => '-- Pilih '.ucwords($table).' --'];
	}
?>