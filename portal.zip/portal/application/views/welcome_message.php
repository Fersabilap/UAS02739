<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	
    <title>Free Bootstrap Admin Template : Binary Admin</title>
	
    <link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/font-awesome.css') ?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/custom.css') ?>" rel="stylesheet" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url('') ?>">Portal E-Berita</a> 
            </div>
			<div style="color: white; padding: 15px 50px 5px 50px; float: right; font-size: 16px;"> Tanggal: <?php echo date("d F Y") ?> &nbsp; <a href="#" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
        
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
					<!-- Photo User -->
					<li class="text-center">
						<img src="<?php echo base_url('assets/img/find_user.png') ?>" class="user-image img-responsive"/>
					</li>
					
					<!-- Tab Menu  -->
                    <li>
                        <a href="<?php echo base_url('/posting') ?>"><i class="fa fa-edit fa-3x"></i> Postingan</a>
                    </li>           
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Tautan Berita <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
							<li>
                                <a href="<?php echo base_url('/gallery') ?>">Galeri</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('/album') ?>">Album</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('/kategori') ?>">Kategori</a>
                            </li>
                            </li>
                        </ul>
                      </li>  
					<li>
                        <a href="<?php echo base_url('/editor') ?>"><i class="fa fa-user fa-3x"></i> Editor</a>
                    </li>	
                </ul>
               
            </div>
            
        </nav>
		
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
					<!-- Content -->
						<h2>Halo!</h2>   
                        <h5>Selamat datang Admin...</h5> 
                    </div>
                </div>
                <hr />
			</div>
        </div>
        </div>
	
	<!-- JavaScipt -->
    <script src="<?php echo base_url('assets/js/jquery-1.10.2.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.metisMenu.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/custom.js') ?>"></script>   
</body>
</html>
