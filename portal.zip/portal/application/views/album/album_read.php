<!doctype html>
<html>
    <head>
        <title>Portal E-Berita</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Album Read</h2>
        <table class="table">
	    <tr><td>Nama Album</td><td><?php echo $nama_album; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('album') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>