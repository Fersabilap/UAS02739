<!doctype html>
<html>
    <head>
        <title>Portal E-Berita</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Album <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Nama Album <?php echo form_error('nama_album') ?></label>
            <input type="text" class="form-control" name="nama_album" id="nama_album" placeholder="Nama Album" value="<?php echo $nama_album; ?>" />
        </div>
	    <input type="hidden" name="id_album" value="<?php echo $id_album; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('album') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>