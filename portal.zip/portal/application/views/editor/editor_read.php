<!doctype html>
<html>
    <head>
        <title>Portal E-Berita</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Editor Read</h2>
        <table class="table">
	    <tr><td>Nama Editor</td><td><?php echo $nama_editor; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Password</td><td><?php echo $password; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('editor') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>