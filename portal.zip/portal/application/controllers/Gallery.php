<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Gallery extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Gallery_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'gallery/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'gallery/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'gallery/index.html';
            $config['first_url'] = base_url() . 'gallery/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Gallery_model->total_rows($q);
        $gallery = $this->Gallery_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'gallery_data' => $gallery,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('gallery/gallery_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Gallery_model->get_by_id($id);
        if ($row) {
            $data = array(
				'id_gallery' => $row->id_gallery,
				'id_album' => $row->id_album,
				'nama_gallery' => $row->nama_gallery,
				'keterangan' => $row->keterangan,
				'photo' => $row->photo,
			);
            $this->load->view('gallery/gallery_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('gallery'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('gallery/create_action'),
			'id_gallery' => set_value('id_gallery'),
			'id_album' => set_value('id_album'),
			'nama_gallery' => set_value('nama_gallery'),
			'keterangan' => set_value('keterangan'),
			'photo' => set_value('photo'),
		);
        $this->load->view('gallery/gallery_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
				'id_album' => $this->input->post('id_album',TRUE),
				'nama_gallery' => $this->input->post('nama_gallery',TRUE),
				'keterangan' => $this->input->post('keterangan',TRUE),
			);
			
			if (!empty($_FILES['photo']['name'])) {
				$upload = $this->_do_upload();
				$data['photo'] = $upload;
			}

            $this->Gallery_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('gallery'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Gallery_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('gallery/update_action'),
				'id_album' => set_value('id_album', $row->id_album),
				'nama_gallery' => set_value('nama_gallery', $row->nama_gallery),
				'keterangan' => set_value('keterangan', $row->keterangan),
				'photo' => set_value('photo', $row->photo),
			);
            $this->load->view('gallery/gallery_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('gallery'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_gallery', TRUE));
        } else {
            $data = array(
				'id_album' => $this->input->post('id_album',TRUE),
				'nama_gallery' => $this->input->post('nama_gallery',TRUE),
				'keterangan' => $this->input->post('keterangan',TRUE),
			);
			
			if (!empty($_FILES['photo']['name'])) {
				$upload = $this->_do_upload();
				$gallery = $this->myModel->get_by_id($this->input->post('id_gallery'));
				if (file_exists('foto_upload/'.$gallery->photo) && $gallery->photo) {
					unlink('foto_upload/'.$gallery->photo);
				}
				$data['photo'] = $upload;
			}

            $this->Gallery_model->update($this->input->post('id_gallery', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('gallery'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Gallery_model->get_by_id($id);

        if ($row) {
            $this->Gallery_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('gallery'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('gallery'));
        }
    }

    public function _rules() 
    {
		$this->form_validation->set_rules('nama_gallery', 'nama gallery', 'trim|required');
		$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim|required');

		$this->form_validation->set_rules('id_gallery', 'id_gallery', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
	
	private function _do_upload() {
		$nmfile = date("dmyhis");
		$code = round(microtime(true) * 1000);
		
		$config['upload_path'] = '';
		$config['allowed_types'] = '';
		$config['max_size'] = '';
		$config['max_width'] = '';
		$config['max_height'] = '';
		$config['file_name'] = '$nmfile'.'-'.'$code';
		
		$this->load->library('upload', $config);
		
		if(!$this->upload->do_upload('photo')) {
			$data['inputerror'][] = 'photo';
			$data['error_string'][] = 'Upload error: '.$this->upload->display_errors('', '');
			$data['status'] = FALSE;
			echo json_encode($data);
			exit();
		}
		
		return $this->upload->data('file_name');
	}

}